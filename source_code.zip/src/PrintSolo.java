//import java.io.*;
//import java.util.ResourceBundle;
//
///**
// * Created by origami on 2018/03/19.
// */
//public class PrintSolo {
//    private PrintWriter pw;
//    private int indentLevel;
//    private Input2Data I2D;
//    private String inputPath;
//    private ResourceBundle rb;
//    private String cssFile;
//    private String cssFolder;
//    private String imgFolder;
//
//    public PrintSolo(String outputPath, String inputPath){
//        this.indentLevel = 0;
//        this.inputPath = inputPath;
//        this.I2D = new Input2Data();
//        try{
//            File file = new File(outputPath);
//            this.pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));
//        }catch(IOException e){
//            System.out.println(e);
//        }
//        this.rb = ResourceBundle.getBundle("solo");
//        this.cssFile = rb.getString("cssFile");
//        this.cssFolder = rb.getString("cssFolder");
//        this.imgFolder = rb.getString("imgFolder");
//    }
//
//    public void loadData() throws FileNotFoundException {
//        this.I2D.convert(this.inputPath);
//        for(int k=0;k<this.I2D.getTeam().length;k++) {
//            for (int i = 0; i < this.I2D.getTeam()[k].getPlayers().size(); i++) {
//                this.I2D.getTeam()[k].getPlayers().get(i).setPosition(I2D.getTeam()[k].getPlayerCount());
//                this.I2D.getTeam()[k].getPlayers().get(i).setReserve(I2D.getTeam()[k].getChange(),I2D.getTeam()[k].getReserves());
//            }
//        }
//    }
//
//    public void writeMain(){
//        println("<!DOCTYPE html>");
//        writeHeader();
//        writeBody();
//        print("</html>");
//        pw.close();
//    }
//
//    public void writeHeader(){
//        println("<head>\n" +
//                "    <meta charset=\"utf-8\">\n" +
//                "    <meta http-equiv=\"content-language\" content=\"ja\">\n" +
//                "    <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">\n" +
//                "    <link rel=\"stylesheet\" href=\"%s/%s.css\">\n" +
//                "</head>",this.cssFolder,this.cssFile);
//    }
//
//    public void writeBody(){
//        println("<body>");
//        incIndent();
//        writeTitle();
//        writeInfo();
//        for(int turnCount=0;turnCount<I2D.getTeamCount();turnCount++) {
//            writeTeamBlock(turnCount);
//        }
//        writeEnd();
//        decIndent();
//        println("</body>");
//    }
//
//    public void writeTitle(){
//        String title = I2D.getMultiInfo().getTitle();
//        println("<div class=\"title\">%s</div>", title);
//    }
//    public void writeInfo(){
//        println("<div class=\"info\">%s</div>", I2D.getMultiInfo().getOthers());
//    }
//
//
//    public void writeTeamBlock(int turnCount){
//        println("<div class=\"team_block\">");
//        incIndent();
//        writeTeam(turnCount);
//        writeResult(turnCount);
//        decIndent();
//        println("</div>");
//    }
//
//    public void writeTeam(int turnCount){
//        String team = "個人";
//        if(!I2D.getMultiInfo().getTeams().isEmpty()){
//            if(!I2D.getMultiInfo().getTeams().get(turnCount).isEmpty()){
//                team = I2D.getMultiInfo().getTeams().get(turnCount);
//            }
//        }
//        println("<div class=\"team\">%s</div>", team);
//    }
//
//    public void writeResult(int turnCount){
//        println("<div class=\"result\">");
//        incIndent();
//        writeTable(turnCount);
//        decIndent();
//        println("</div>");
//    }
//
//    public void writeTable(int turnCount){
//        println("<table>");
//        incIndent();
//        writeTrHeader(turnCount);
//        for(int i=0;i<I2D.getTeam()[turnCount].getPlayerCount();i++){
//            writeTrPlayer(turnCount, i);
//        }
//        decIndent();
//        println("</table>");
//    }
//
//    public void writeTrHeader(int turnCount){
//        println("<tr class=\"header\">");
//        incIndent();
//        println("<th class=\"name\">氏名</th>");
//        println("<th class=\"grade\">学年</th>");
//        for(int i=0;i<I2D.getTeam()[turnCount].getTableHeader().getHeadName().size();i++) {
//            println("<th class=\"set\">%s</th>",I2D.getTeam()[turnCount].getTableHeader().getHeadName().get(i));
//        }
//        println("<th class=\"total\">合計</th>");
//        decIndent();
//        println("</tr>");
//    }
//
//    public void writeTrPlayer(int turnCount, int order){
//        println("<tr>");
//        incIndent();
//        println("<td>%s</td>", I2D.getTeam()[turnCount].getPlayers().get(order).getName());
//        println("<td>%s</td>", I2D.getTeam()[turnCount].getPlayers().get(order).getGrade());
//        hit(turnCount, order);
//        println("<td>%s</td>", I2D.getTeam()[turnCount].getPlayers().get(order).getTotal());
//        decIndent();
//        println("</tr>");
//    }
//    public void hit(int turnCount, int order){
//        int counter=0;
//        for(int k=0;k<I2D.getTeam()[turnCount].getTableHeader().getSplitCount().size();k++) {
//            print("<td>");
//            for (int i = 0; i < Math.ceil((double)(I2D.getTeam()[turnCount].getTableHeader().getSplitCount().get(k)) / 2.0); i++) {
//                nonTabPrint("<img src=\"%s/%s.gif\">",this.imgFolder, I2D.getTeam()[turnCount].getPlayers().get(order).getScore2by2(counter++));
//            }
//            nonTabPrintln("</td>");
//        }
//    }
//
//    public void writeEnd(){
//        println("<div class=\"end\">");
//        incIndent();
//        println("結果");
//        println("（ここに記入）");
//        decIndent();
//        println("</div>");
//    }
//
//    public void incIndent(){
//        this.indentLevel++;
//    }
//    public void decIndent(){
//        this.indentLevel--;
//    }
//    public void print(String format, Object... args){
//        for(int i=0;i<this.indentLevel;i++){pw.print("    ");}
//        pw.printf(format,args);
//    }
//    public void nonTabPrint(String format, Object... args){
//        pw.printf(format,args);
//    }
//    public void println(String format, Object... args){
//        for(int i=0;i<this.indentLevel;i++){pw.print("    ");}
//        pw.printf(format,args);
//        pw.print("\n");
//    }
//    public void nonTabPrintln(String format, Object... args){
//        pw.printf(format,args);
//        pw.print("\n");
//    }
//}
